exports.LOW_VOLATILITY_30 =
  "https://www1.nseindia.com/content/indices/ind_nifty_quality_lowvol30list.csv";
exports.MIDCAP_QUALITY_50 =
  "https://www1.nseindia.com/content/indices/ind_niftymidcap150quality50list.csv";
exports.MOMENTUM_30 =
  "https://www1.nseindia.com/content/indices/ind_nifty200Momentum30_list.csv";
exports.ALPHA_QUALITY_VALUE_30 =
  "https://www1.nseindia.com/content/indices/ind_nifty_alpha_quality_value_lowvol30list.csv";
